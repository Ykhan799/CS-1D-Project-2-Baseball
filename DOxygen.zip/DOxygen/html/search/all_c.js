var searchData=
[
  ['u_72',['u',['../struct_edge.html#a60a34279415f9bff8844f0c0a8675ae3',1,'Edge']]],
  ['updatesouvenirs_73',['updateSouvenirs',['../classmanage_d_b.html#aacc430781e4340035b98717963a319d5',1,'manageDB']]],
  ['updateteams_74',['updateTeams',['../classmanage_d_b.html#adaffd4005163f96893856428cc524a2b',1,'manageDB']]]
];
