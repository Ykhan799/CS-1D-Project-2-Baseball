var searchData=
[
  ['loggedin_45',['loggedIn',['../classlogin.html#a6b0c0886ac0fe76eecaec7a7878bef9b',1,'login']]],
  ['login_46',['login',['../classlogin.html',1,'']]]
];
