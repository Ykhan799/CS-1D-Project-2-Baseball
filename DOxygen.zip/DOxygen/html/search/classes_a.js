var searchData=
[
  ['tripsummary_112',['tripSummary',['../classtrip_summary.html',1,'']]]
];
