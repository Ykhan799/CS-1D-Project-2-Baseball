var searchData=
[
  ['dateopened_101',['dateOpened',['../classmanage_d_b.html#a99345cb9fd900a76f3f96de21cbcc984',1,'manageDB']]]
];
