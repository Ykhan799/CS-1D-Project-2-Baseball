var indexSectionsWithContent =
{
  0: "abcdeglmorstuvw~",
  1: "cdeglmost",
  2: "adglrstu~",
  3: "bdmstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

