var searchData=
[
  ['team_5fname_5fdestination_152',['team_name_destination',['../structdistance_edge.html#ae46b06feb4c35fcbaa198ddda8b4e8e1',1,'distanceEdge']]],
  ['team_5fname_5forigin_153',['team_name_origin',['../structdistance_edge.html#ab76099a4d0397c36f1295243f696b396',1,'distanceEdge']]]
];
