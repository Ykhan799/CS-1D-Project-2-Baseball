var searchData=
[
  ['tripsummary_94',['tripSummary',['../classtrip_summary.html',1,'']]]
];
