var searchData=
[
  ['mainwindow_87',['MainWindow',['../class_main_window.html',1,'']]],
  ['managedb_88',['manageDB',['../classmanage_d_b.html',1,'']]],
  ['marlinspath_89',['marlinsPath',['../classmarlins_path.html',1,'']]],
  ['modifysouvenirs_90',['modifySouvenirs',['../classmodify_souvenirs.html',1,'']]],
  ['modifyteams_91',['modifyTeams',['../classmodify_teams.html',1,'']]]
];
