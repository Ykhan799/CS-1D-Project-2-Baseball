var searchData=
[
  ['removesouvenir_130',['removeSouvenir',['../classmanage_d_b.html#a635c749ba7a9135ef3b181ebd422a97f',1,'manageDB']]]
];
