var searchData=
[
  ['updatesouvenirs_144',['updateSouvenirs',['../classmanage_d_b.html#aacc430781e4340035b98717963a319d5',1,'manageDB']]],
  ['updateteams_145',['updateTeams',['../classmanage_d_b.html#adaffd4005163f96893856428cc524a2b',1,'manageDB']]]
];
