var searchData=
[
  ['updatesouvenirs_62',['updateSouvenirs',['../classmanage_d_b.html#aacc430781e4340035b98717963a319d5',1,'manageDB']]],
  ['updateteams_63',['updateTeams',['../classmanage_d_b.html#a3b93730ce68833d42d6f57244aa584bf',1,'manageDB']]]
];
