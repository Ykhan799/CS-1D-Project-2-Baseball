var searchData=
[
  ['vertex_64',['Vertex',['../struct_vertex.html',1,'']]]
];
