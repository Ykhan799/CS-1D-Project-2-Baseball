var searchData=
[
  ['mainwindow_77',['MainWindow',['../class_main_window.html',1,'']]],
  ['managedb_78',['manageDB',['../classmanage_d_b.html',1,'']]],
  ['marlinspath_79',['marlinsPath',['../classmarlins_path.html',1,'']]],
  ['modifysouvenirs_80',['modifySouvenirs',['../classmodify_souvenirs.html',1,'']]],
  ['modifyteams_81',['modifyTeams',['../classmodify_teams.html',1,'']]]
];
