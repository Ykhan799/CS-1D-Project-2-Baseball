var searchData=
[
  ['loggedin_121',['loggedIn',['../classlogin.html#a6b0c0886ac0fe76eecaec7a7878bef9b',1,'login']]]
];
