var searchData=
[
  ['mainwindow_48',['MainWindow',['../class_main_window.html',1,'']]],
  ['managedb_49',['manageDB',['../classmanage_d_b.html',1,'']]],
  ['marlinspath_50',['marlinsPath',['../classmarlins_path.html',1,'']]],
  ['modifysouvenirs_51',['modifySouvenirs',['../classmodify_souvenirs.html',1,'']]],
  ['modifyteams_52',['modifyTeams',['../classmodify_teams.html',1,'']]]
];
