var searchData=
[
  ['addedge_0',['addEdge',['../classgraph_helper.html#a96ff98c61ba471740f56756bcf79e942',1,'graphHelper']]],
  ['addsouvenir_1',['addSouvenir',['../classmanage_d_b.html#a51f5775e0ca26c6cbe3bd5b1883e2d76',1,'manageDB']]],
  ['addteam_2',['addTeam',['../classmanage_d_b.html#abb81e446fa1c2d1052a9c466b2b90273',1,'manageDB']]],
  ['addteamdistances_3',['addTeamDistances',['../classmanage_d_b.html#ae743d0e52700c6cd08e23fefae6d6302',1,'manageDB']]],
  ['addteamsouvenirs_4',['addTeamSouvenirs',['../classmanage_d_b.html#afdf667955e3b151a6ccf02aa0bfefd17',1,'manageDB']]]
];
