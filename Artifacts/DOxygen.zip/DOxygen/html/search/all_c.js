var searchData=
[
  ['teamexists_61',['teamExists',['../classmanage_d_b.html#a9bf5d518bf0ef71a02e0dcec7da26d48',1,'manageDB']]]
];
