var searchData=
[
  ['vertex_83',['Vertex',['../struct_vertex.html',1,'']]]
];
